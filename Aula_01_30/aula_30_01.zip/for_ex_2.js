// contador regressivo
for (let i = 5; i >= 0; i--) {
  console.log(i);
}
