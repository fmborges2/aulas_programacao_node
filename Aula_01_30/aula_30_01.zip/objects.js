//criando objeto
let pessoa = { nome: "Fernando", idade: 30 };

//acessando objeto
console.log(pessoa.nome);
console.log(pessoa["idade"]);

//inserindo novo atributo:
pessoa.cidade = "Alfenas";

//saída
console.log(pessoa);